//
//  GameController.h
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"
#import "Sprite.h"
#import "Goods.h"




@interface GameController : UIViewController<UIScrollViewDelegate,UIAlertViewDelegate>{

}

@property (strong, nonatomic) IBOutlet UILabel     *gslab;          //第几关
@property (strong, nonatomic) IBOutlet UILabel     *dflab;          //得分
@property (strong, nonatomic) IBOutlet UILabel     *gflab;          //过关分数
@property (strong, nonatomic) IBOutlet UILabel     *zflab;          //总分
@property (strong, nonatomic) IBOutlet UIImageView *timeImg;        //时间槽
@property (strong, nonatomic) IBOutlet UITableViewCell *showPanel;  //得分栏面板 
@property (strong, nonatomic) IBOutlet UITableViewCell *spritePanel;//精灵出现的面板


@property (nonatomic, assign)  int     gs;          //第几关数
@property (nonatomic, assign)  int     df;          //本关得分数
@property (nonatomic, assign)  int     gf;          //过关分数
@property (nonatomic, assign)  int     zf;          //总分数

@property (nonatomic, assign)  int     hitFen;      //敲打得分

//道具 

@property (nonatomic, assign)  int     zsVal;          //钻石增值水 1 2   钻石分数双倍 //
@property (nonatomic, assign)  int     xyVal;          //四叶幸运草 4 1.5 钻石概率*1.5 宝箱中出古董概率*1.5//
@property (nonatomic, assign)  int     jsVal;          //金属提纯器 2 2   所有金属分数双倍//
@property (nonatomic, assign)  int     ffVal;          //防火服    3 0   炸弹分数变为0
@property (nonatomic, assign)  int     sdVal;          //魔法手电筒 5 0   宝箱为空的概率变为0   //
@property (nonatomic, assign)  int     slVal;          //鼠粮      6 1   每轮出现的小精灵增加1只
@property (nonatomic, assign)  int     sgVal;          //古董时光机 7 2   古董价值*2

@property (strong, nonatomic) Goods *pubGood;

//信息栏
@property (strong, nonatomic) IBOutlet UILabel *mslab1; //信息1
@property (strong, nonatomic) IBOutlet UILabel *mslab2; //信息2
@property (nonatomic, assign) int   mspin;     //信息针
@property (nonatomic, assign) CGRect msframe1; // 信息位置
@property (nonatomic, assign) CGRect msframe2; // 信息位置


//游戏

@property (nonatomic, assign) int       carPin;           //关数
@property (nonatomic, assign) CGFloat   alternationTime;  //每轮间格时间
@property (nonatomic, assign) CGFloat   imgPTime;         //图片过度时间
@property (nonatomic, assign) CGFloat   stayTime;         //精灵停留时间
@property (nonatomic, assign) CGFloat   postSum;          //过关分数
@property (nonatomic, assign) int       eachTC;           //每关轮数
@property (nonatomic, assign) int       TCPin;            //轮数指针
@property (nonatomic, assign) int       spriteNum;        //每轮小精灵只数


@property (nonatomic, assign) int       carPinS;          //上一关


@property (strong, nonatomic) NSDictionary *myDic;            //plist中所有内容
@property (strong, nonatomic) NSMutableArray *allSpriteArray; //所有种类的精灵和机率
@property (nonatomic, assign) int      selectNumPin;          //选择指针
@property (strong, nonatomic) NSMutableArray *tempNumArray;   //所有的每轮只数和机率
@property (strong, nonatomic) NSMutableArray *allFrame;       //所有的frame;
@property (nonatomic, assign) int      isShowPin;             //精灵显示指针，按数组位置顺序


//购买物品
@property (strong, nonatomic) IBOutlet UILabel *mblab;           //目标得分
@property (strong, nonatomic) IBOutlet UILabel *dcdflab;         //当前得分
@property (strong, nonatomic) IBOutlet UIScrollView *buyScroll;  //购买容器视图
@property (strong, nonatomic) NSMutableArray *buyArray;          //购买内容数组
@property (strong, nonatomic) NSMutableArray *buyFrame;          //道具位置
@property (strong, nonatomic) IBOutlet UITableViewCell *buyCell; //道具视图


@property (strong, nonatomic) UIAlertView *buyAlert;       //购买弹出框
@property (strong, nonatomic) UIAlertView *gameAlert;      //游戏通关弹出框
@property (strong, nonatomic) UITextField *nameText;       //用户名输入框
@property (nonatomic, assign) int          buyTag;         //购买物品的tag
@property (strong, nonatomic) UIAlertView *gameOVAlert;    //游戏结束框


//敲的精灵触发到的方法
-(IBAction)hitSprite:(id)sender;


//购买物品道
-(void)buyGoods:(id)sender;


//开始游戏
-(IBAction)startGame;

//更新得分信息栏
-(void)updateGameMssess:(NSString *)str;

//显示精灵
-(void)showSprite;

//重设每关参数
-(void)reSetNewGame;

//取精灵的身份
-(int)getSpriteNum;

//显示道具
-(void)showPropertys;

//下一关游戏
-(IBAction)NextGame;


@end
