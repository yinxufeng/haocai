//
//  ViewController.h
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameController.h"
#import "Common.h"
#import "SingCell.h"


@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>{

    GameController *GController;
    
}


@property (strong, nonatomic) IBOutlet UIButton *starBTN;           //开始游戏按钮
@property (strong, nonatomic) IBOutlet UIButton *infoBTN;           //战网按钮
@property (strong, nonatomic) IBOutlet UIButton *helpBTN;           //帮助按钮
@property (strong, nonatomic) IBOutlet UIButton *exitBTN;           //退出按钮

@property (strong, nonatomic) IBOutlet UITableViewCell *helpView;   //帮助视图
@property (strong, nonatomic) IBOutlet UIView *infoView;            //排行视图

@property (strong, nonatomic) IBOutlet UITableView *infoTable;      //排行信息表

@property (strong, nonatomic) NSMutableArray *infoArray;           //战网数据
@property (strong, nonatomic) IBOutlet UILabel *pmlab;            //排名

/*按钮操作*/
-(IBAction)btnAction:(id)sender;

//显示游戏排行
-(void)showGameInfo;

//显示帮助
-(void)showHelp;
@end
