//
//  SingCell.m
//  Sprite
//
//  Created by  on 12-7-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SingCell.h"

@implementation SingCell

@synthesize labid,labname,labsum;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        labid=[[UILabel alloc] initWithFrame:CGRectMake(5, 2, 60, 30)];
        [labid setFont:[UIFont systemFontOfSize:14.0f]];
        [labid setTextColor:[UIColor blackColor]];
        
        [labid setBackgroundColor:[UIColor clearColor]];
        
        labname=[[UILabel alloc] initWithFrame:CGRectMake(100, 2, 100, 30)];
        [labname setFont:[UIFont systemFontOfSize:14.0f]];
        [labname setBackgroundColor:[UIColor clearColor]];
        [labname setTextColor:[UIColor blackColor]];
        
        
        labsum=[[UILabel alloc] initWithFrame:CGRectMake(240, 2, 60, 30)];
        [labsum setFont:[UIFont systemFontOfSize:14.0f]];
        [labsum setBackgroundColor:[UIColor clearColor]];
        [labsum setTextColor:[UIColor blackColor]];
        
        [[self contentView] addSubview:labid];	
        [[self contentView] addSubview:labname];	
        [[self contentView] addSubview:labsum];	
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
