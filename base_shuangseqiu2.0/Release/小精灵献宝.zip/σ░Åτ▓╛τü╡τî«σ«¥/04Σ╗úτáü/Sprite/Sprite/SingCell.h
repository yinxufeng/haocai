//
//  SingCell.h
//  Sprite
//
//  Created by  on 12-7-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SingCell : UITableViewCell{

    UILabel *labid;    //显示id
    UILabel *labname;  //显示用户名
    UILabel *labsum;   //显示分数
}


@property (strong, nonatomic)IBOutlet UILabel *labid;    //显示id
@property (strong, nonatomic)IBOutlet UILabel *labname;  //显示用户名
@property (strong, nonatomic)IBOutlet UILabel *labsum;   //显示分数


@end
