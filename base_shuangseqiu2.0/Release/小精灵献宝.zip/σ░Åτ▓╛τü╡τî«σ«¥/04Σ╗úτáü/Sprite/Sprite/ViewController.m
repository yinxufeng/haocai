//
//  ViewController.m
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize starBTN,infoBTN,helpBTN,exitBTN;
@synthesize helpView,infoView,infoTable;
@synthesize infoArray;
@synthesize pmlab;




- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view addSubview:helpView];
    [self.view addSubview:infoView];
    [helpView setHidden:YES];
    [infoView setHidden:YES];
    infoArray=[[NSMutableArray alloc] initWithArray:[[Common DictFromPlist:@"zw"]objectForKey:@"zw"]];


}

- (void)viewDidUnload{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
-(void)viewWillAppear:(BOOL)animated{

    [starBTN   setImage:[UIImage imageNamed:@"nav_start.png"] forState:0];
    [infoBTN   setImage:[UIImage imageNamed:@"nav_order.png"] forState:0];
    [helpBTN   setImage:[UIImage imageNamed:@"nav_help.png"] forState:0];
    [exitBTN   setImage:[UIImage imageNamed:@"nav_exit.png"]  forState:0];
    

}

/*按钮操作*/
-(IBAction)btnAction:(id)sender{
    
    
    UIButton *btn=(UIButton *)sender;
    
    //修改按钮背景图
    [starBTN   setImage:btn.tag==0?[UIImage imageNamed:@"nav_start_on.png"]:[UIImage imageNamed:@"nav_start.png"] forState:0];
    [infoBTN   setImage:btn.tag==1?[UIImage imageNamed:@"nav_order_on.png"]:[UIImage imageNamed:@"nav_order.png"] forState:0];
    [helpBTN   setImage:btn.tag==2?[UIImage imageNamed:@"nav_help_on.png"]:[UIImage imageNamed:@"nav_help.png"] forState:0];
    [exitBTN   setImage:btn.tag==3?[UIImage imageNamed:@"nav_exit_on.png"]:[UIImage imageNamed:@"nav_exit.png"]  forState:0];

    switch (btn.tag) {
            /*开始游戏*/
        case 0:{
            if (!GController) {
                GController=[[GameController alloc] init];
            }

            [self presentModalViewController:GController animated:YES];
        }break;
            
            /*战网排行*/    
        case 1:{

            [Common playViews:@"oglFlip" setDele:self setView:infoView];
            [infoView setHidden:NO];
//            [infoArray removeAllObjects];
//            [infoArray setArray:[dbdao getResults]];
//            [infoTable reloadData];
            
        }break;
            
            /*帮助*/
        case 2:{
            
            [Common playViews:@"oglFlip" setDele:self setView:helpView];
            [helpView setHidden:NO];
            
            
        }break;
            
            /*退出*/
        case 3:{

            exit(0);
            
        }break;
            
            /*退出*/
        case 4:{
            
            [Common playViews:@"oglFlip" setDele:self setView:infoView];
            [infoView setHidden:YES];
            
        }break;
            
            /*退出*/
        case 5:{
            
            [Common playViews:@"oglFlip" setDele:self setView:helpView];
            [helpView setHidden:YES];
            
        }break;
            
        default:break;
    }
}


//显示游戏排行
-(void)showGameInfo{


}

//显示帮助
-(void)showHelp{

}


#pragma  tableview delegate and dataSource

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    NSString *CellIdentifier=[NSString stringWithFormat:@"CellIdentifier%d",indexPath.row];
    SingCell *cell = (SingCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[SingCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    if (indexPath.row%2==0) {
    
        cell.contentView.backgroundColor=[UIColor orangeColor];
    }else {
        cell.contentView.backgroundColor=[UIColor yellowColor];
    }
    cell.labid.text=[[infoArray objectAtIndex:indexPath.row] valueForKey:@"id"];
    cell.labname.text=[[infoArray objectAtIndex:indexPath.row] valueForKey:@"name"];
    cell.labsum.text=[[infoArray objectAtIndex:indexPath.row] valueForKey:@"sum"];

//        cell.labid.text=[NSString stringWithFormat:@"%d",indexPath.row+1];
//        cell.labname.text=[[infoArray objectAtIndex:indexPath.row] userName];
//        cell.labsum.text=[NSString stringWithFormat:@"%d",[[infoArray objectAtIndex:indexPath.row] res]];
//    
//    if ([uName isEqualToString:[[infoArray objectAtIndex:indexPath.row] userName]]) {
//        pmlab.text=[NSString stringWithFormat:@"你目前排名：第 %d 名",indexPath.row+1];
//        
//    }else {
//        pmlab.text=[NSString stringWithFormat:@"你目前排名："];
//    }
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 38;

}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return [infoArray count];
}


//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
//    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
//}

@end
