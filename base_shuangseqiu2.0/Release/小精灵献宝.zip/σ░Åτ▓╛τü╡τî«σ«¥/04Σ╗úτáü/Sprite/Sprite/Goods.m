//
//  Goods.m
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Goods.h"

@implementation Goods
@synthesize gname,gtype,clickSta,img,imgoff,vals,desc,effict,num,tag;

@end
