//
//  Sprite.m
//  Sprite
//
//  Created by kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Sprite.h"

@implementation Sprite
@synthesize sname,stype,hitSta,img,hitimg,tag,val,desc,percent;



@end
