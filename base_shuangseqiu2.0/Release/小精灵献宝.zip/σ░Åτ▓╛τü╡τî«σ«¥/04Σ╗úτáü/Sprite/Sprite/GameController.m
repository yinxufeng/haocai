//
//  GameController.m
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GameController.h"


@implementation GameController

@synthesize gslab,dflab,gflab,zflab,timeImg,showPanel,spritePanel;
@synthesize carPin,carPinS,alternationTime,imgPTime,stayTime,postSum;
@synthesize myDic,eachTC,TCPin,spriteNum;
@synthesize allSpriteArray,selectNumPin,tempNumArray,allFrame,isShowPin;
@synthesize mblab,dcdflab,buyScroll,buyArray,buyCell,buyFrame;
@synthesize gs,df,gf,zf;
@synthesize zsVal,xyVal,jsVal,ffVal,sdVal,slVal,sgVal,hitFen;

@synthesize buyAlert,gameAlert,gameOVAlert,nameText,buyTag;
@synthesize pubGood;
@synthesize mslab1,mslab2,mspin,msframe1,msframe2;



//敲的精灵触发到的方法
-(IBAction)hitSprite:(id)sender{

    hitFen=0;
    
    Sprite *sps=(Sprite *)sender;
    for (id obj in [self.spritePanel subviews]) {
        if([obj isKindOfClass:[Sprite class]]){
            Sprite *s = (Sprite *)obj;
            if ([sps isEqual:s]) {

                if (s.stype==8) {//炸弹 炸弹分数变为0 或否
                    [s setImage:[UIImage imageNamed:@"preeleff1.png"] forState:0];
                    
                    hitFen=s.val*ffVal;
 
                }else {
                    [s setImage:[UIImage imageNamed:@"preeleff0.png"] forState:0];
                }
                
                if (s.stype<6) {//所有金属分数双倍
                   hitFen=s.val*jsVal;

                }
                
                if (s.stype==6) {//钻石分数双倍
                    
                    hitFen=s.val*zsVal;

                }
                
                if (s.stype==7) {//宝箱 古董价值
                    NSArray *tempA;
                    
                    if (xyVal==1.5 && sdVal==0) {//如果宝箱中开出的宝物的道具效果
                        tempA=[NSArray arrayWithArray:[Common getAllCimexy]];//幸运草
                    }else if(xyVal==1.5 && sdVal==1){
                        tempA=[NSArray arrayWithArray:[Common getAllCimexysd]];//幸运草＋手电筒
                    }else if(xyVal==1 && sdVal==1) {
                        tempA=[NSArray arrayWithArray:[Common getAllCimesd]];//手电筒
                    }else if(xyVal==1 && sdVal==0){
                        tempA=[NSArray arrayWithArray:[Common getAllCime]];//常规
                    }
                    
                    if ([[[tempA objectAtIndex:0] objectForKey:@"id"] intValue]<6) {
                        hitFen=[[[tempA objectAtIndex:0] objectForKey:@"value"] intValue]*jsVal;
                    }
                    
                    if ([[[tempA objectAtIndex:0] objectForKey:@"id"] intValue]==6) {
                        hitFen=[[[tempA objectAtIndex:0] objectForKey:@"value"] intValue]*zsVal;
                               
                    }
                    
                    if ([[[tempA objectAtIndex:0] objectForKey:@"id"] intValue]==10) {
                        
                        hitFen=[[[Common getGDValue:[NSMutableArray arrayWithArray:[[[tempA objectAtIndex:0] objectForKey:@"value"] componentsSeparatedByString:@","]]] objectAtIndex:0] intValue]*sgVal;//古董价值＊时光机器效果
        
                    
                    }
                    
                    [s setDesc:[[tempA objectAtIndex:0] objectForKey:@"desc"]];
             
                }
                
                [s setFrame:CGRectMake(s.frame.origin.x, s.frame.origin.y+8, s.frame.size.width, s.frame.size.height-8)];
                
                NSLog(@"carPin %d   hidFen=%d  desc=%@",carPin,hitFen,s.desc);
                [self updateGameMssess:[NSString stringWithFormat:@"%@  %@%d;",s.desc,(hitFen<=0?@"":@"+"),hitFen]];
            }
        }
        
    }
    zf+=hitFen;
    df+=hitFen;
   
    dflab.text=[NSString stringWithFormat:@"本关获分：%d",df];
    zflab.text=[NSString stringWithFormat:@"总分：%d",zf];

}


//更新得分信息
-(void)updateGameMssess:(NSString *)str{
    switch (mspin) {
        case 0:{
            mslab1.text=str;
            mspin=1;
        }break;
        case 1:{
        
            mslab1.frame=msframe1;
            mslab2.text=str;
            mslab2.frame=msframe2;
            
            mspin=2;
        }break;
        case 2:{
        
            mslab1.frame=msframe2;
            mslab2.frame=msframe1;
            mslab1.text=str;
            mspin=1;
        }break;
        default:break;
    }
    

}


//购买物品道
-(void)buyGoods:(id)sender{

    Goods *gds=(Goods *)sender;
    pubGood=gds;
    self.buyTag=gds.gtype;
    NSString *str=[NSString stringWithFormat:@"%@可以使\n%@ \n你确定要花%d分来购买\n",[gds gname],[gds desc],[gds vals]];
    buyAlert=[[UIAlertView alloc] initWithTitle:nil
                                        message:str 
                                       delegate:self 
                              cancelButtonTitle:@"确定" 
                              otherButtonTitles:@"取消", nil];
    
    UIImageView *alertImg=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"face01.png"]];
    [alertImg setFrame:CGRectMake(10, 10, 50, 80)];
    [buyAlert addSubview:alertImg];
    [buyAlert show];
    
    
}

#pragma UIAlertView Delegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView==buyAlert) {
        
        if (buttonIndex==0) {
            switch (self.buyTag) {
                    //钻石增值水
                case 1:{ zsVal=2;NSLog(@"钻石分数双倍");}break;
                    //金属提纯器
                case 2:{ jsVal=2;NSLog(@"所有金属分数双倍");}break;
                    //防火服
                case 3:{ffVal=0;NSLog(@"炸弹分数变为0");}break;
                    //四叶幸运草 
                case 4:{xyVal=1.5;NSLog(@"古董钻石概率*1.5");}break;
                    //魔法手电筒   
                case 5:{sdVal=1;NSLog(@"挖出的宝箱绝对不会是空箱子");}break;
                    //鼠粮  
                case 6:{slVal=1;NSLog(@"每轮出现的小精灵增加1只");}break;
                    //古董时光机  
                case 7:{sgVal=2;NSLog(@"古董价值*2");}break;
                    
                default: break;
            }

        [pubGood setEnabled:NO];
        zf=zf-[pubGood vals];//总份一去买价
        dcdflab.text=[NSString stringWithFormat:@"当前得分：%d",zf];
        }
        
    }
    
    if (alertView==gameAlert) {//通关
        [self showPropertys];
        NSLog(@"用户名：%@",nameText.text);

 

        
    }
    
    if (alertView==gameOVAlert) {//游戏结束
        [self dismissModalViewControllerAnimated:YES];
       
    }
    
}

//下一关
-(IBAction)NextGame{
    
    [Common playViews:@"pageCurl" setDele:self setView:buyCell];
    [buyCell setHidden:YES];
    gf=[[[myDic objectForKey:@"pastSum"]objectAtIndex:carPin]intValue];
    int showCarPin=carPin+1;
    gslab.text=[NSString stringWithFormat:@"第 %d 关",showCarPin];
    dflab.text=@"本关获分：";
    df=0;
    gflab.text=[NSString stringWithFormat:@"过关分数：%d",gf];
    zflab.text=[NSString stringWithFormat:@"总分：%d",zf];
    

    [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(startGame) userInfo:nil repeats:NO];

}


//显示道具
-(void)showPropertys{
    
    mslab1.text=@"";
    mslab2.text=@"";
    
    gf=[[[myDic objectForKey:@"pastSum"]objectAtIndex:carPin]intValue];
    dcdflab.text=[NSString stringWithFormat:@"当前得分：%d",zf];
    mblab.text=[NSString stringWithFormat:@"本关目标：%d",gf];
    
    for (id obj in [buyScroll subviews]) {
        [obj removeFromSuperview];

    }
    
    [self.view addSubview:buyCell];
    buyScroll.contentSize=CGSizeMake(buyScroll.frame.size.width, buyScroll.frame.size.height+230);
    
    if (buyArray) {
        [buyArray removeAllObjects];
    }
    buyArray=[Common getAllProperty];

    for (int i=0; i<[buyFrame count]; i++) {//随机取三种道提供购买
        
        @autoreleasepool {
            
        Goods *gd=[[Goods alloc] init];
        [gd setGname:[[buyArray objectAtIndex:i]objectForKey:@"name"]];
        [gd setGtype:[[[buyArray objectAtIndex:i]objectForKey:@"id"]intValue]];
        [gd setClickSta:NO];
        [gd setImg:[[buyArray objectAtIndex:i]objectForKey:@"image"]];
        [gd setImgoff:[[buyArray objectAtIndex:i]objectForKey:@"imageoff"]];
        [gd setNum:[[[buyArray objectAtIndex:i]objectForKey:@"num"]intValue]];
        [gd setDesc:[[buyArray objectAtIndex:i]objectForKey:@"desc"]];
        [gd setEffict:[[buyArray objectAtIndex:i]objectForKey:@"effect"]];
        [gd setVals:[[[buyArray objectAtIndex:i]objectForKey:@"value"]intValue]];
        [gd setTag:[[[buyArray objectAtIndex:i]objectForKey:@"id"]intValue]];
        
        if (zf>[[[buyArray objectAtIndex:i]objectForKey:@"value"]intValue]) {
            [gd setImage:[UIImage imageNamed:[[buyArray objectAtIndex:i]objectForKey:@"image"]] forState:0];
        }else {
            [gd setImage:[UIImage imageNamed:[[buyArray objectAtIndex:i]objectForKey:@"imageoff"]] forState:0];
            [gd setEnabled:NO];
        }
        
        [gd setFrame:CGRectMake(25, 10, 75, 70)];

        [gd addTarget:self action:@selector(buyGoods:) forControlEvents:UIControlEventTouchUpInside];
        UILabel *prLab=[[UILabel alloc] initWithFrame:CGRectMake(0, 75, 120, 50)];
        [prLab setTextColor:[UIColor whiteColor]];
        [prLab setBackgroundColor:[UIColor clearColor]];
        
        [prLab setText:[[buyArray objectAtIndex:i]objectForKey:@"desc"]];
        [prLab setTextAlignment:UITextAlignmentCenter];
        [prLab setNumberOfLines:2];
        [prLab setFont:[UIFont systemFontOfSize:13.0f]];
        
        UITableViewCell *prCell=[[UITableViewCell alloc] init];
        [prCell setFrame:CGRectFromString([buyFrame objectAtIndex:i])];
        [prCell setBackgroundColor:[UIColor clearColor]];
        
        
        //是否设置边框以及是否可见  
        [[prCell layer] setMasksToBounds:YES];  
        //设置边框圆角的弧度  
        [[prCell layer] setCornerRadius:10.0];  
        //设置边框线的宽   
        [[prCell layer] setBorderWidth:2];  
        //设置边框线的颜色  
    
        [[prCell layer] setBorderColor:[[UIColor whiteColor] CGColor]];  
        
        if (zf>[[[buyArray objectAtIndex:i]objectForKey:@"value"]intValue]) {
            
             [[prCell layer] setBorderColor:[[UIColor greenColor] CGColor]];;
        }else {
             [[prCell layer] setBorderColor:[[UIColor whiteColor] CGColor]];
        }

        [prCell addSubview:prLab];
        [prCell addSubview:gd];
        
        [buyScroll addSubview:prCell];
        }
    }


    [buyCell setHidden:NO];
}

//开始游戏
-(IBAction)startGame{
   [NSTimer scheduledTimerWithTimeInterval:(alternationTime+imgPTime)/1000 target:self selector:@selector(showSprite) userInfo:nil repeats:NO];
}

//显示精灵
-(void)showSprite{
    
    [timeImg setFrame:CGRectMake(timeImg.frame.origin.x, timeImg.frame.origin.y, timeImg.frame.size.width-(260/eachTC), timeImg.frame.size.height)];
    
    if (TCPin<eachTC) {//只数指针小于每轮指定只数时 开始显示操作
        [self startGame];
        
        for(id obj in [self.spritePanel subviews]){
            if([obj isKindOfClass:[Sprite class]]){
                Sprite *s = (Sprite *)obj;
                [s removeFromSuperview];
            }
            if([obj isKindOfClass:[UIButton class]]){
                UIButton *b = (UIButton *)obj;
                [b removeFromSuperview];
            }
        }  
        
        //显示每轮的精灵 随机后向后轮显
        Sprite *sp;
        spriteNum=[self getSpriteNum];
        
        if ((isShowPin+spriteNum)>=20) {isShowPin=0;}//如果所以区间超过数组索引范围就将区间指针置0

            allFrame=[Common refurbishSprite:allFrame];
        for (int i=isShowPin; i<(isShowPin+spriteNum); i++) {
            
            @autoreleasepool {
                sp=[[Sprite alloc] init];
                [sp setSname:[[allSpriteArray objectAtIndex:i]objectForKey:@"name"]];
                [sp setStype:[[[allSpriteArray objectAtIndex:i]objectForKey:@"id"]intValue]];
                [sp setVal:[[[allSpriteArray objectAtIndex:i]objectForKey:@"value"]intValue]];
                [sp setDesc:[[allSpriteArray objectAtIndex:i]objectForKey:@"desc"]];
                [sp setPercent:[[allSpriteArray objectAtIndex:i]objectForKey:@"percent"]];
                [sp setImg:[[allSpriteArray objectAtIndex:i]objectForKey:@"plimage"]];
                [sp setHitimg:[[allSpriteArray objectAtIndex:i]objectForKey:@"hitimg"]];
                [sp setTag:i];
               
                [sp setImage:[UIImage imageNamed:[[allSpriteArray objectAtIndex:i]objectForKey:@"plimage"]] forState:0];
                [sp setFrame:CGRectFromString([allFrame objectAtIndex:i-isShowPin])];
                [sp addTarget:self action:@selector(hitSprite:) forControlEvents:UIControlEventTouchUpInside];
                [Common playSpriteView:sp];
                [self.spritePanel addSubview:sp];
                
            }
        }
        isShowPin+=spriteNum;

    }else {//本轮轮数显示完毕
        NSString *dfstr=[NSString stringWithFormat:@"得分：%d \n玩家姓名：\n\n",zf];
        if (zf<gf) {//游戏结速

            gameOVAlert=[[UIAlertView alloc] initWithTitle:@"游戏结束"
                                                   message:dfstr 
                                                  delegate:self 
                                         cancelButtonTitle:@"确定" 
                                         otherButtonTitles:nil, nil];
            
            UIImageView *alertImg=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"face03.png"]];
            [alertImg setFrame:CGRectMake(25, 30, 50, 66)];
            
            nameText=[[UITextField alloc] initWithFrame:CGRectMake(100, 93, 100, 20)];
            [nameText setBackgroundColor:[UIColor whiteColor]];
            [nameText setTextAlignment:UITextAlignmentLeft];
            
            [gameOVAlert addSubview:alertImg];
            [gameOVAlert addSubview:nameText];
            
            [gameOVAlert show];
            
            
        }else {//通关
            gameAlert=[[UIAlertView alloc] initWithTitle:@"游戏通关"
                                                   message:dfstr 
                                                  delegate:self 
                                         cancelButtonTitle:@"确定" 
                                         otherButtonTitles:nil, nil];
            
            UIImageView *alertImg=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"face03.png"]];
            [alertImg setFrame:CGRectMake(25, 30, 50, 66)];
            
            nameText=[[UITextField alloc] initWithFrame:CGRectMake(100, 93, 100, 20)];
            [nameText setBackgroundColor:[UIColor whiteColor]];
            [nameText setTextAlignment:UITextAlignmentLeft];
            
            [gameAlert addSubview:alertImg];
            [gameAlert addSubview:nameText];
            
            [gameAlert show];
        }
        
        carPin++;//下一关
        [self reSetNewGame];
        NSLog(@"NEXT ==%d",carPin+1);
    }
    
    TCPin++;
}


//游戏重设置
-(void)reSetNewGame{
    
    [timeImg setFrame:CGRectMake(timeImg.frame.origin.x,timeImg.frame.origin.y, 260, timeImg.frame.size.height)];
    
    
    for (id obj in [spritePanel subviews]) {
        if ([obj isKindOfClass:[Sprite class]]) {
            [obj removeFromSuperview];
        }
    }
    
    self.TCPin=0;
    if (carPin>=10) {
       carPin=0;
    }
    self.alternationTime=[[[myDic objectForKey:@"alternationTime"] objectAtIndex:carPin] floatValue];
    self.eachTC=[[[myDic objectForKey:@"eachCT"] objectAtIndex:carPin] floatValue];
    self.imgPTime=[[[myDic objectForKey:@"imgPTime"] objectAtIndex:carPin] floatValue];

    //游戏结束，道具效果清除
    zsVal=1;//钻石分数双倍或1倍
    xyVal=1;//钻石概率*1.5 宝箱中出古董概率*1.5 或1
    jsVal=1;//所有金属分数双倍 或1倍
    ffVal=1;//炸弹分数变为0为0分 1时为－20分
    sdVal=0;//1时 宝箱为空的概率变为0 0时存在空箱
    slVal=0;//每轮出现的小精灵增加1只 0时不加
    sgVal=1;//1时不变 2时古董价值*2

}

//取精灵个数
-(int)getSpriteNum{//注意过关的时候要把selectNumPin设0；
    int tempint=0;

    if (carPinS!=carPin) {
        carPinS=carPin;
        selectNumPin=0;
    }
    
    if (selectNumPin==0) {
       [tempNumArray removeAllObjects];
       tempNumArray =[[NSMutableArray alloc] initWithArray:[[[myDic objectForKey:@"spriteNum"] objectAtIndex:carPin] componentsSeparatedByString:@","]];
    
        if (tempNumArray) {
            int i=20,j=0;
            while (--i>0) {
                j=rand() % (i+1);
                [tempNumArray exchangeObjectAtIndex:i withObjectAtIndex:j];
            }
        }
    }
    tempint=[[tempNumArray objectAtIndex:selectNumPin] intValue];
    selectNumPin++;
    
    if (selectNumPin==20) {
        selectNumPin=0;
    }
    return tempint+slVal;
}


//视图出现时
-(void)viewWillAppear:(BOOL)animated{

    [timeImg setFrame:CGRectMake(timeImg.frame.origin.x,timeImg.frame.origin.y, 260, timeImg.frame.size.height)];
    
    carPin=0;
    carPinS=0;
    selectNumPin=0;
    spriteNum=0;
    zf=0;
    
    tempNumArray=[[NSMutableArray alloc] init];
    myDic=[[NSMutableDictionary alloc] initWithDictionary:[Common DictFromPlist:@"Sprite"]];
    self.imgPTime=[[[myDic objectForKey:@"imgPTime"] objectAtIndex:carPin] floatValue];
    self.alternationTime=[[[myDic objectForKey:@"alternationTime"] objectAtIndex:carPin] floatValue];
    self.eachTC=[[[myDic objectForKey:@"eachCT"] objectAtIndex:carPin] floatValue];
    self.buyArray=[[NSMutableArray alloc] init];
    self.buyFrame=[[NSMutableArray alloc] initWithArray:[myDic objectForKey:@"allProFrame"]];
    buyScroll.delegate=self;
    
    self.allFrame=[Common getAllFrame];
    allSpriteArray=[Common getAllSprite];
    
    //游戏开始前，道具效果清除
    zsVal=1;//钻石分数双倍或1倍
    xyVal=1;//钻石概率*1.5 宝箱中出古董概率*1.5 或1
    jsVal=1;//所有金属分数双倍 或1倍
    ffVal=1;//炸弹分数变为0为0分 1时为－20分
    sdVal=0;//1时 宝箱为空的概率变为0 0时存在空箱
    slVal=0;//每轮出现的小精灵增加1只 0时不加
    sgVal=1;//1时不变 2时古董价值*2
    
    [timeImg setFrame:CGRectMake(timeImg.frame.origin.x, timeImg.frame.origin.y, timeImg.frame.size.width, timeImg.frame.size.height)];
    [self showPropertys];
}

//视图加载
- (void)viewDidLoad{
    [super viewDidLoad];
    msframe1=CGRectMake(15, 8, 291, 21);
    msframe2=CGRectMake(15, 37, 291, 21);
    mspin=0;

}

- (void)viewDidUnload{
    [super viewDidUnload];
}

//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
//    return (interfaceOrientation == UIInterfaceOrientationPortrait);
//}

@end
