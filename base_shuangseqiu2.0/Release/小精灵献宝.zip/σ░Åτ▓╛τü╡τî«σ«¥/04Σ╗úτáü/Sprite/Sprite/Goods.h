//
//  Goods.h
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Goods : UIButton{

}

@property (strong, nonatomic) NSString  *gname;  //物品名称
@property (nonatomic, assign) NSInteger gtype;   //物品类型
@property (nonatomic) BOOL clickSta;             //点击状态
@property (strong, nonatomic) NSString  *img;    //背景图片
@property (strong, nonatomic) NSString  *imgoff; //无法购买时背景图
@property (nonatomic, assign) int tag;           //按钮标记
@property (nonatomic, assign) int vals;          //道具价值
@property (strong, nonatomic) NSString  *desc;   //道具描术
@property (strong, nonatomic) NSString  *effict; //道具效果
@property (nonatomic, assign) int       num;     //道具效果指数


@end
