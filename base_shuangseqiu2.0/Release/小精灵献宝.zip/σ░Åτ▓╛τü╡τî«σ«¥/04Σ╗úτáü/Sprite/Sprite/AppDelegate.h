//
//  AppDelegate.h
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@class ViewController;                                          //引入视ViewController类


@interface AppDelegate : UIResponder <UIApplicationDelegate>   //AppDelegate继承UIResponder实引入UIApplicationDelegate代理

@property (strong, nonatomic) UIWindow *window;                //uiwindow对象变量

@property (strong, nonatomic) ViewController *viewController;  //视图控制器变量

@end
