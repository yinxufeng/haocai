//
//  Sprite.h
//  Sprite
//
//  Created by kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Sprite : UIButton<NSCoding>{


}
@property (strong, nonatomic) NSString  *sname;  //精灵名称
@property (nonatomic, assign) NSInteger stype;   //精灵类型
@property (nonatomic) BOOL hitSta;               //敲打状态
@property (strong, nonatomic) NSString  *img;    //背景图片
@property (strong, nonatomic) NSString  *hitimg; //敲打后背景图
@property (nonatomic, assign) int tag;           //按钮标记
@property (nonatomic, assign) int val;           //价值 
@property (strong, nonatomic) NSString *desc;    //简介
@property (strong, nonatomic) NSString *percent; //机率



@end
