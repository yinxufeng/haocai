//
//  Common.h
//  Sprite
//
//  Created by  on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface Common : NSObject



/* 取中路径 EXAMP  : [common getPath:@"xx.xml"]; */
+(NSString *)getPath:(NSString *)fileName;

/*常用动画操作*/
+(void)playViews:(NSString *)str setDele:(id)del setView:(UIView *)views;

//取plist中角色信息
+(NSMutableDictionary *)getPlistInfo:(NSString *)fileName;


//取用户战绩排名
+(NSArray *)getResult;

//*取古董分*
+(NSMutableArray *)getGDValue:(NSMutableArray *)array;

//对数组进行乱序产生机率
+(NSMutableArray *)refurbishSprite:(NSMutableArray *)array;

/*取每次的cimelia*/
+(NSMutableArray *)getAllCime;

/*取每次的cimeliasd*/
+(NSMutableArray *)getAllCimesd;

/*取每次的cimeliaxy*/
+(NSMutableArray *)getAllCimexy;

/*取每次的cimeliaxysd*/
+(NSMutableArray *)getAllCimexysd;



/*读取项目本plist */
+(NSDictionary *)DictFromPlist:(NSString *)fileName;

+(void)playSpriteView:(UIView *)pin;

/*取所有的frame*/
+(NSMutableArray *)getAllFrame;

//取道具
+(NSMutableArray *)getAllProperty;

/*取每次的sprite*/
+(NSMutableArray *)getAllSprite;

/*取每轮的次数*/
+(NSMutableArray *)getAllNum:(NSMutableArray *)array setCarPin:(int)pin;
@end
