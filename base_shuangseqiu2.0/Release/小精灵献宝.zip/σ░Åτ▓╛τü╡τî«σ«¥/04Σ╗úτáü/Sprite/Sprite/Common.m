//
//  common.m
//  Sprite
//
//  Created by  kpchen on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Common.h"
#import <QuartzCore/QuartzCore.h>

@implementation Common



/* 取中路径 EXAMP  : [common getPath:@"xx.xml"]; */
+(NSString *)getPath:(NSString *)fileName{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	if (fileName==nil) {
		return documentsDirectory;
	}else{
		return [documentsDirectory stringByAppendingPathComponent:fileName];	
	}
}



/*常用动画操作*/
+(void)playViews:(NSString *)str setDele:(id)del setView:(UIView *)views{
    
    CATransition * cat=[CATransition animation];
    cat.delegate = del;
    cat.duration = 0.5f * 1 ;//slider.value;
	cat.fillMode = kCAFillModeForwards;
	cat.endProgress = 1;//slider.value;
	cat.removedOnCompletion = NO;
	cat.type = str;//cube suckEffect oglFlip rippleEffect pageCurl pageUnCurl cameraIrisHollowOpen cameraIrisHollowClose
    [views.layer removeAnimationForKey:@"annomation"];
    [views.layer addAnimation:cat forKey:@"annomation"];
    
}

//取plist中角色信息
+(NSMutableDictionary *)getPlistInfo:(NSString *)fileName{
    
    if (fileName==nil || [[fileName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] isEqualToString:@""]){
        return nil;//这种情况几乎不存在
    }else{
        
        NSFileManager *fileManager=[NSFileManager defaultManager];
		BOOL isExist=[fileManager fileExistsAtPath:[Common getPath:fileName]];
		
		if (isExist) {
            //如果plist文件存在就读取该文件
            return [NSMutableDictionary dictionaryWithContentsOfFile:[Common getPath:fileName]];
		}else{
            //plist文件不存在
            return [NSMutableDictionary dictionaryWithObjectsAndKeys:@"plist文件不存在", nil];
        }
        
    }
}




//取用户战绩排名
+(NSArray *)getResult{
    return nil;
}

//对数组进行乱序产生机率
+(NSMutableArray *)refurbishSprite:(NSMutableArray *)array{
    if (array) {
        int i=[array count],j=0;
        while (--i>0) {
            j=rand() % (i+1);
            [array exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
    }
    return array;
}

/*取古董分*/
+(NSMutableArray *)getGDValue:(NSMutableArray *)array{
    
    NSMutableArray *tempArray;
    
    NSString *filePath=[Common getPath:@"gudongFen.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:array];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % (i+1);
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
    }

    return tempArray;
}

/*取所有的Sprite frame*/
+(NSMutableArray *)getAllFrame{
    
    NSMutableArray *tempArray;
    
    NSString *filePath=[Common getPath:@"refurishFrame.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:[[Common DictFromPlist:@"Sprite"]objectForKey:@"frame"]];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % (i+1);
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
        
    }
    
    return tempArray;
}

//取道具
+(NSMutableArray *)getAllProperty{
    
    NSMutableArray *tempArray;
    
    NSString *filePath=[Common getPath:@"properytFrame.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:[[Common DictFromPlist:@"Sprite"]objectForKey:@"property"]];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % i;
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
    }
    return tempArray;
}



/*取每次的cimelia*/
+(NSMutableArray *)getAllCime{
    
    NSMutableArray *tempArray;
    NSString *filePath=[Common getPath:@"cimelia.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:[[Common DictFromPlist:@"Sprite"]objectForKey:@"cimelia"]];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % i;
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
    }
    return tempArray;
}

/*取每次的cimeliasd*/
+(NSMutableArray *)getAllCimesd{

    NSMutableArray *tempArray;
    NSString *filePath=[Common getPath:@"cimeliasd.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:[[Common DictFromPlist:@"Sprite"]objectForKey:@"cimeliasd"]];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % i;
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
    }
    
    return tempArray;
}

/*取每次的cimeliaxy*/
+(NSMutableArray *)getAllCimexy{

    NSMutableArray *tempArray;
    NSString *filePath=[Common getPath:@"cimeliaxy.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:[[Common DictFromPlist:@"Sprite"]objectForKey:@"cimeliaxy"]];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % i;
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
        
    }
    return tempArray;

}

/*取每次的cimeliaxysd*/
+(NSMutableArray *)getAllCimexysd{

    
    NSMutableArray *tempArray;
    
    NSString *filePath=[Common getPath:@"cimeliaxysd.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:[[Common DictFromPlist:@"Sprite"]objectForKey:@"cimeliaxysd"]];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % i;
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
        
    }
    return tempArray;
}


/*取每次的sprite*/
+(NSMutableArray *)getAllSprite{
    
    NSMutableArray *tempArray;
    NSString *filePath=[Common getPath:@"refurishSprite.plist"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:[[Common DictFromPlist:@"Sprite"]objectForKey:@"goods"]];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % i;
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
    }
    return tempArray;

}


/*取每轮的次数*/
+(NSMutableArray *)getAllNum:(NSMutableArray *)array setCarPin:(int)pin{
    
    NSMutableArray *tempArray;
    NSString *filePath=[Common getPath:[NSString stringWithFormat:@"refurishNum%d.plist",pin]];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    BOOL isExist=[fileManager fileExistsAtPath:filePath];
    
    if (isExist) {
        tempArray=[NSMutableArray  arrayWithContentsOfFile:filePath];
    }else{
        tempArray=[NSMutableArray arrayWithArray:array];
    }
    
    if (tempArray) {
        int i=[tempArray count],j=0;
        while (--i>0) {
            j=rand() % (i+1);
            [tempArray exchangeObjectAtIndex:i withObjectAtIndex:j];
        }
        [tempArray writeToFile:filePath atomically:YES];
    }
    return tempArray;
}

//精灵动画
+(void)playSpriteView:(UIView *)pin{
    
    CABasicAnimation *cab;
	cab=[CABasicAnimation animationWithKeyPath:@"transform.translation.y"];
	cab.duration=0.05;
	cab.repeatCount=1;
	cab.autoreverses=YES;
	cab.fromValue=[NSNumber numberWithFloat:15];
	cab.toValue=[NSNumber numberWithFloat:0];
    [pin.layer removeAnimationForKey:@"animateLayer"];
	[pin.layer addAnimation:cab forKey:@"animateLayer"];
}


/*读取项目本plist */
+(NSDictionary *)DictFromPlist:(NSString *)fileName{
    return [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:fileName ofType:@"plist"]];
}

@end
